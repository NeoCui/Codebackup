//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mine.rc
//
#define IDD_MINE_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDR_MENU                        129
#define IDB_MINE_COLOR                  131
#define IDB_BTN_GRAY                    132
#define IDB_MINE_GRAY                   133
#define IDB_NUM_COLOR                   134
#define IDB_NUM_GRAY                    135
#define IDB_BTN_COLOR                   136
#define IDR_WAVE_DEAD                   139
#define IDR_WAVE_CLOCK                  140
#define IDR_WAVE_VICTORY                141
#define IDD_DLG_NEWRECORD               142
#define IDD_DLG_HERO                    143
#define IDD_DLG_CUSTOM                  144
#define IDC_EDIT_NAME                   1000
#define IDC_RESET                       1001
#define IDC_B_R                         1002
#define IDC_B_H                         1003
#define IDC_I_R                         1004
#define IDC_I_H                         1005
#define IDC_E_R                         1006
#define IDC_E_H                         1007
#define IDC_DESCRIBE                    1008
#define IDC_HEIGHT                      1009
#define IDC_WIDTH                       1010
#define IDC_NUMBER                      1011
#define IDM_START                       32771
#define IDM_PRIMARY                     32772
#define IDM_SECOND                      32773
#define IDM_ADVANCE                     32774
#define IDM_CUSTOM                      32775
#define IDM_MARK                        32776
#define IDM_COLOR                       32777
#define IDM_SOUND                       32778
#define IDM_HERO                        32779
#define IDM_EXIT                        32780
#define IDM_HELP_LIST                   32781
#define IDM_HELP_FIND                   32782
#define IDM_HELP_USE                    32783
#define IDM_ABOUT                       32784
#define IDM_CHEAT                       32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
